namespace ContactManagementAPI.Models
{
    public class UserInfo
    {
        public int Id { get; set; }
        public string EmailId { get; set; }
        public string Password { get; set; }
        public string Role { get; set; }
    }
}
